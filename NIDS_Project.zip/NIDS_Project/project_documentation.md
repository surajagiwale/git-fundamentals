# 🛡️ Network Intrusion Detection and Prevention System (NIDS/NIPS)

**मराठी अर्थ:** *"नेटवर्कमधील अनधिकृत प्रवेश आणि सायबर हल्ले शोधून त्यांना प्रतिबंध करणारी प्रणाली."*

A real-time cybersecurity monitoring and prevention web application built using **Python, Scapy, Flask, SQLite/MySQL, and System Firewall (`iptables`/`netsh`)**. This system captures incoming and outgoing network packets, detects suspicious activities (like Port Scanning, Brute Force, and DoS attacks), alerts the administrator, and automatically blocks malicious IP addresses.

---

## 📌 १. प्रकल्पाची मुख्य वैशिष्ट्ये (Key Features)

1. **NIDS (Network Intrusion Detection System):** 
   * Captures live network traffic using `Scapy`.
   * Analyzes packet headers (TCP, UDP, ICMP) and payload sizes to detect anomalies.
   * Generates real-time security alerts with severity levels (`High`, `Medium`, `Low`).
2. **NIPS (Network Intrusion Prevention System):**
   * Automatically blocks suspicious IP addresses using OS-level firewall rules (`iptables` on Linux / `netsh` on Windows).
3. **Interactive Admin Dashboard:**
   * Live traffic metrics (Total Packets, Normal Traffic, Suspicious Traffic, Blocked IPs).
   * Real-time network traffic chart (`Chart.js`).
   * Dedicated views for **Live Traffic Monitor**, **Security Alerts**, **Attack Logs**, and **Blocked IPs**.
   * Instant **Security Alert Popup** notification for critical threats.
4. **Dual Mode Support:**
   * **Simulation Mode:** Generates realistic dummy traffic and attacks for easy classroom/college demonstrations.
   * **Real Sniffing Mode:** Captures actual network interface packets on your LAN/Wi-Fi.

---

## 🏗️ २. प्रकल्पाची संरचना (Project Architecture)

```text
[Internet / Network Traffic] 
        │
        ▼
[Packet Capture (Scapy)] 
        │
        ▼
[Traffic Analysis & Detection (Python + Rules)]
        ├──► Normal Traffic ──────► [Allow Traffic]
        │
        └──► Suspicious Traffic ──► [Firewall (NIPS)] ──► Block IP (iptables / netsh)
                    │
                    ▼
           [Database (SQLite / MySQL)]
                    │
                    ▼
      [Admin Dashboard (Flask + HTML/CSS/JS)]
```

---

## 📂 ३. फोल्डरची रचना (Folder Structure)

Create a folder named `NIDS_Project` on your computer and organize the files as shown below:

```text
NIDS_Project/
│
├── app.py                 # Main Python backend (Flask + Scapy + Firewall logic)
├── nids_database.db       # SQLite Database (Auto-generated on first run)
├── requirements.txt       # List of required Python libraries
├── README.md              # Project documentation and setup guide
└── templates/
    └── dashboard.html     # Frontend UI Dashboard (HTML + Tailwind + Chart.js)
```

---

## ⚙️ ४. पूर्वतयारी आणि इन्स्टॉलेशन (Prerequisites & Installation)

Follow these step-by-step instructions to set up the project on **Windows** or **Linux (Ubuntu/Kali)**.

### Step 1: Install Python
* Make sure **Python 3.8 or higher** is installed on your computer.
* Verify installation by opening Terminal / Command Prompt and typing:
  ```bash
  python --version
  ```

### Step 2: Install Packet Capture Driver (Important for Scapy)
To capture real network packets, `Scapy` requires a system packet driver:
* **For Windows:** Download and install **[Npcap](https://npcap.com/#download)**. 
  * *Note:* During installation, check the box **"Install Npcap in WinPcap API-compatible Mode"**.
* **For Linux (Ubuntu / Kali):** Install `libpcap` using terminal:
  ```bash
  sudo apt-get update
  sudo apt-get install tcpdump libpcap-dev
  ```

### Step 3: Set Up Project Folder & Virtual Environment (Optional but Recommended)
Open your Terminal or Command Prompt and run the following commands:

```bash
# 1. Create and navigate to the project directory
mkdir NIDS_Project
cd NIDS_Project

# 2. Create a virtual environment
python -m venv venv

# 3. Activate the virtual environment
# On Windows:
venv\Scripts\activate
# On Linux/Mac:
source venv/bin/activate
```

### Step 4: Install Required Python Libraries
Run the following command to install Flask, Scapy, and MySQL connector:

```bash
pip install flask scapy mysql-connector-python
```

*(Alternatively, you can create a `requirements.txt` file containing `flask`, `scapy`, and `mysql-connector-python`, and run `pip install -r requirements.txt`)*

---

## 🚀 ५. प्रोजेक्ट कसा रन करावा? (How to Run the Project)

You can run this project in two ways depending on your requirement:

### पध्दत A: Demo / Simulation Mode (कॉलेज प्रेझेंटेशनसाठी सर्वोत्तम)
By default, `SIMULATION_MODE = True` is set in `app.py`. This automatically simulates network packets and cyber attacks every 2 seconds so your graphs and tables look active immediately.

1. Open Terminal / CMD inside the `NIDS_Project` folder.
2. Run the application:
   ```bash
   python app.py
   ```
3. Open your web browser (Chrome/Edge/Firefox) and go to:
   ```text
   http://127.0.0.1:5000
   ```

---

### पध्दत B: Real Network Monitoring Mode (खऱ्या नेटवर्कवर तपासणीसाठी)
If you want to capture actual packets from your college LAN or Wi-Fi and block real IPs:

1. Open `app.py` in a code editor (like VS Code) and change line 21:
   ```python
   SIMULATION_MODE = False
   ```
2. Enable actual firewall execution inside `block_ip_firewall()` in `app.py` by uncommenting `os.system(cmd)`.
3. **Run Terminal as Administrator / Root** (Required for packet sniffing and firewall rules):
   * **On Windows (Run CMD as Administrator):**
     ```cmd
     python app.py
     ```
   * **On Linux:**
     ```bash
     sudo python3 app.py
     ```
4. Open your browser and visit `http://127.0.0.1:5000`.

---

## 🧪 ६. प्रोजेक्टचे टेस्टिंग कसे करावे? (How to Test Attacks in Real Mode)

Suppose you have connected two computers on the same Wi-Fi/LAN network:
* **Computer A (Victim / Server):** Running this NIDS/NIPS project (`IP: 192.168.1.50`).
* **Computer B (Attacker):** Another laptop on the same network (`IP: 192.168.1.100`).

From **Computer B**, run the following commands to trigger alerts on **Computer A's** dashboard:

1. **Test Port Scanning Attack (Using Nmap):**
   ```bash
   nmap -p 1-100 192.168.1.50
   ```
   * **Result:** The NIDS will detect multiple port requests from `192.168.1.100`, log a **Port Scanning (High Severity)** alert, and NIPS will block the IP.

2. **Test DoS / Large Packet Flood (Using Ping):**
   * **On Windows:**
     ```cmd
     ping 192.168.1.50 -l 2000 -t
     ```
   * **On Linux:**
     ```bash
     ping -s 2000 192.168.1.50
     ```
   * **Result:** Packets larger than 1400 bytes will be flagged as **Suspicious Traffic**, and an alert will appear on the dashboard.

---

## 🛠️ ७. सामान्य अडचणी आणि उपाय (Troubleshooting)

* **Error: `PermissionError: [Errno 1] Operation not permitted` (When using Scapy)**
  * **Solution:** You must run your Command Prompt as **Administrator** (Windows) or use `sudo` (Linux) when `SIMULATION_MODE = False`.
* **Error: `RuntimeError: Sniffing and sending packets is not available at layer 2: winpcap is not installed`**
  * **Solution:** Install **Npcap** on Windows and make sure to check *"WinPcap API-compatible Mode"*.
* **How to Unblock an IP blocked by the Firewall?**
  * **On Linux:**
    ```bash
    sudo iptables -D INPUT -s <IP_ADDRESS> -j DROP
    ```
  * **On Windows (Admin CMD):**
    ```cmd
    netsh advfirewall firewall delete rule name="Block <IP_ADDRESS>"
    ```

---

## 👨‍💻 ८. तंत्रज्ञान (Technologies Used)

* **Backend:** Python 3, Flask
* **Networking & Security:** Scapy (Packet Sniffing), Linux `iptables` / Windows `netsh` (Firewall NIPS)
* **Database:** SQLite3 (Built-in) / MySQL
* **Frontend:** HTML5, Tailwind CSS, JavaScript (Fetch API), Chart.js, FontAwesome Icons