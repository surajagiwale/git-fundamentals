import os
import sqlite3
import threading
import time
import random
import platform
from datetime import datetime
from flask import Flask, render_template, jsonify

# Scapy इम्पोर्ट करणे (रियल नेटवर्क ट्रॅफिकसाठी)
try:
    from scapy.all import sniff, IP, TCP, UDP, ICMP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

app = Flask(__name__)
DB_NAME = "nids_database.db"

# टेस्टिंगसाठी ट्रॅफिक सिम्युलेशन चालू ठेवायचे असल्यास True ठेवा, खऱ्या नेटवर्कसाठी False करा
SIMULATION_MODE = False  

# आकडेवारी साठवण्यासाठी व्हेरिएबल्स
stats = {
    "total_packets": 12450,
    "normal_traffic": 11980,
    "suspicious_traffic": 470,
    "blocked_ips": 3
}

# १. डेटाबेस सेटअप (SQLite / MySQL पर्याय)
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    
    # Live Traffic टेबल
    c.execute('''CREATE TABLE IF NOT EXISTS live_traffic
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, src_ip TEXT, dst_ip TEXT, 
                  protocol TEXT, size TEXT, status TEXT, time TEXT)''')
    
    # Security Alerts आणि Attack Logs टेबल
    c.execute('''CREATE TABLE IF NOT EXISTS alerts
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT, src_ip TEXT, 
                  dst_ip TEXT, attack_type TEXT, severity TEXT, status TEXT)''')
    
    # Blocked IPs टेबल
    c.execute('''CREATE TABLE IF NOT EXISTS blocked_ips
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, ip TEXT UNIQUE, 
                  reason TEXT, blocked_at TEXT, status TEXT)''')
    
    # सुरुवातीचा डमी डेटा (फोटोमध्ये दाखवल्याप्रमाणे)
    c.execute("SELECT COUNT(*) FROM blocked_ips")
    if c.fetchone()[0] == 0:
        initial_blocks = [
            ("192.168.1.105", "Brute Force", "10:19:15", "Blocked"),
            ("192.168.1.120", "Unauthorized Access", "10:21:40", "Blocked"),
            ("192.168.1.140", "Malicious Traffic", "10:23:50", "Blocked")
        ]
        c.executemany("INSERT INTO blocked_ips (ip, reason, blocked_at, status) VALUES (?, ?, ?, ?)", initial_blocks)
        
        initial_alerts = [
            ("10:20 AM", "192.168.1.100", "192.168.1.1", "Port Scanning", "High", "Detected"),
            ("10:17 AM", "192.168.1.105", "192.168.1.10", "Brute Force", "High", "Blocked"),
            ("10:14 AM", "192.168.1.110", "192.168.1.50", "DoS Attack", "Medium", "Blocked")
        ]
        c.executemany("INSERT INTO alerts (time, src_ip, dst_ip, attack_type, severity, status) VALUES (?, ?, ?, ?, ?, ?)", initial_alerts)

    conn.commit()
    conn.close()

# २. फायरवॉलद्वारे IP ब्लॉक करणे (NIPS कार्यप्रणाली)
def block_ip_firewall(ip_address, reason):
    now = datetime.now().strftime("%H:%M:%S")
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO blocked_ips (ip, reason, blocked_at, status) VALUES (?, ?, ?, ?)",
                  (ip_address, reason, now, "Blocked"))
        conn.commit()
        stats["blocked_ips"] += 1
        
        # खऱ्या सिस्टीमवर फायरवॉल कमांड रन करणे (फोटो ८ प्रमाणे)
        current_os = platform.system()
        if current_os == "Linux":
            # Linux iptables कमांड (Admin/Root परवानगी आवश्यक)
            cmd = f"iptables -A INPUT -s {ip_address} -j DROP"
            print(f"[NIPS FIREWALL] Executing: {cmd}")
            # os.system(cmd)  # प्रत्यक्ष ब्लॉक करण्यासाठी समोरील '#' काढा
        elif current_os == "Windows":
            cmd = f'netsh advfirewall firewall add rule name="Block {ip_address}" dir=in action=block remoteip={ip_address}'
            print(f"[NIPS FIREWALL] Executing: {cmd}")
            os.system(cmd)
            
    except sqlite3.IntegrityError:
        pass  # IP आधीच ब्लॉक केलेला आहे
    finally:
        conn.close()

# ३. पॅकेट तपासणी आणि हल्ला शोधणे (NIDS कार्यप्रणाली)
port_scan_tracker = {}

def analyze_packet(src_ip, dst_ip, proto, size, dport=None):
    now_time = datetime.now().strftime("%I:%M %p")
    now_sec = datetime.now().strftime("%H:%M:%S")
    status = "Normal"
    attack_type = None
    severity = "Low"
    action_status = "Detected"

    stats["total_packets"] += 1

    # नियम १: Port Scanning ओळखणे (एकाच IP वरून वेगवेगळ्या पोर्ट्सवर विनंती)
    if dport:
        if src_ip not in port_scan_tracker:
            port_scan_tracker[src_ip] = set()
        port_scan_tracker[src_ip].add(dport)
        
        if len(port_scan_tracker[src_ip]) > 10:
            status = "Suspicious"
            attack_type = "Port Scanning"
            severity = "High"
            action_status = "Blocked"
            block_ip_firewall(src_ip, attack_type)
            port_scan_tracker[src_ip].clear()

    # नियम २: मोठ्या आकाराचे पॅकेट्स (DoS किंवा संशयास्पद ट्रॅफिक)
    if size > 1400 and status == "Normal":
        status = "Suspicious"
        attack_type = random.choice(["DoS Attack", "Brute Force", "Unauthorized Access"])
        severity = "High" if attack_type != "DoS Attack" else "Medium"
        action_status = "Blocked" if severity == "High" else "Detected"
        if action_status == "Blocked":
            block_ip_firewall(src_ip, attack_type)

    if status == "Normal":
        stats["normal_traffic"] += 1
    else:
        stats["suspicious_traffic"] += 1

    # डेटाबेसमध्ये नोंद करणे
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO live_traffic (src_ip, dst_ip, protocol, size, status, time) VALUES (?, ?, ?, ?, ?, ?)",
              (src_ip, dst_ip, proto, f"{size} B", status, now_sec))
    
    if attack_type:
        c.execute("INSERT INTO alerts (time, src_ip, dst_ip, attack_type, severity, status) VALUES (?, ?, ?, ?, ?, ?)",
                  (now_time, src_ip, dst_ip, attack_type, severity, action_status))
    
    conn.commit()
    conn.close()

# Scapy पॅकेट कॉलबॅक
def scapy_packet_callback(packet):
    if IP in packet:
        src_ip = packet[IP].src
        dst_ip = packet[IP].dst
        size = len(packet)
        proto = "OTHER"
        dport = None

        if TCP in packet:
            proto = "TCP"
            dport = packet[TCP].dport
        elif UDP in packet:
            proto = "UDP"
            dport = packet[UDP].dport
        elif ICMP in packet:
            proto = "ICMP"

        analyze_packet(src_ip, dst_ip, proto, size, dport)

# बॅकग्राउंड थ्रेड (सिम्युलेशन किंवा खरा स्निफर)
def background_traffic_monitor():
    if not SIMULATION_MODE and SCAPY_AVAILABLE:
        print("[*] Starting Real Scapy Packet Sniffer...")
        sniff(prn=scapy_packet_callback, store=False)
    else:
        print("[*] Running Traffic Simulation Mode for Demo...")
        ips = ["192.168.1.10", "192.168.1.15", "192.168.1.100", "192.168.1.105", "192.168.1.110", "192.168.1.120"]
        protocols = ["TCP", "UDP", "ICMP"]
        while True:
            time.sleep(2)
            src = random.choice(ips)
            dst = f"192.168.1.{random.randint(1, 50)}"
            proto = random.choice(protocols)
            # 20% वेळा संशयास्पद ट्रॅफिक तयार करणे
            size = random.randint(1450, 3400) if random.random() < 0.2 else random.randint(128, 900)
            analyze_packet(src, dst, proto, size)

# ४. Flask वेब राउट्स (Web Routes)
@app.route("/")
def index():
    return render_template("dashboard.html")

@app.route("/api/data")
def get_data():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    c.execute("SELECT * FROM live_traffic ORDER BY id DESC LIMIT 10")
    traffic = [dict(row) for row in c.fetchall()]

    c.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 6")
    alerts = [dict(row) for row in c.fetchall()]

    c.execute("SELECT * FROM blocked_ips ORDER BY id DESC LIMIT 6")
    blocked = [dict(row) for row in c.fetchall()]

    conn.close()
    return jsonify({
        "stats": stats,
        "traffic": traffic,
        "alerts": alerts,
        "blocked": blocked
    })

if __name__ == "__main__":
    init_db()
    t = threading.Thread(target=background_traffic_monitor, daemon=True)
    t.start()
    app.run(debug=True, port=5000)